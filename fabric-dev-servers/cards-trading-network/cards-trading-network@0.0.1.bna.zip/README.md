# cards-trading-network

A Hyperledger Fabric network to trade cards between permissioned participants.
